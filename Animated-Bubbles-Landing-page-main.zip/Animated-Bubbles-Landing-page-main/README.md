# Animated-Bubbles-Landing-page
Simple landing page exercises with animation using html and css only. 
